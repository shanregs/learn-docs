package com.shan.spboot.ms.refdatalookup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefDataLookupApplicationTests {

    @Test
    void contextLoads() {
    }

}
