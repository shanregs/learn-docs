package com.shan.spboot.ms.refdatalookup.trade.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Trade {

    public long id;
    private int version;
    private String code;
    private String sourceSystem;
    private String account;
    private String partyLegalName;

}

