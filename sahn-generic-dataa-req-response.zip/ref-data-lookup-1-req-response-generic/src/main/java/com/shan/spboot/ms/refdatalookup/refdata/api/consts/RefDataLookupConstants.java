package com.shan.spboot.ms.refdatalookup.refdata.api.consts;

public class RefDataLookupConstants {

    public static final String APP_UI = "app_ui";

    public static final String PARTY_LOOKUP_OPERATION = "party";
    public static final String FXSPOT_LETTER_LOOKUP_OPERATION = "fxSpotLetter";
    public static final String UPI_LOOKUP_OPERATION = "upi";


    public static final String LOOKUP_ID_PARTY = "party_1";
    public static final String LOOKUP_ID_FXSPOT_LETTER = "fxSpotLetter_1";
    public static final String LOOKUP_ID_UPI = "upi_1";
    public static final String LOOKUP_ID_UP2 = "upi_2";
}
