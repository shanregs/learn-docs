package com.shan.spboot.ms.refdatalookup.refdata.api.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * Represents the response of a reference data lookup API.
 *
 * <p>This class contains details about the reference data lookup request
 * and its results. It includes information such as the request UUID,
 * source, id, version, status, and a list of lookup results.</p>
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefDataLookupAPIResponse {
    private String requestUUID;
    private String requestSource;
    private Long id;
    private int version;
    private String status;
    private ArrayList<RefDataLookupResult<?>> results = new ArrayList<>();
}
