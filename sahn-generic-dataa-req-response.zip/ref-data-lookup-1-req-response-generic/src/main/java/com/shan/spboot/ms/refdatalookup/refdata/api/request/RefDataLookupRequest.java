package com.shan.spboot.ms.refdatalookup.refdata.api.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedHashMap;

/**
 * Request object to be used as input to the Ref Data Lookup service. The request
 * contains a {@link RefDataLookupAPIRequest} and a {@link LinkedHashMap} of
 * {@link RefDataLookup} objects. The {@link RefDataLookupAPIRequest} describes the
 * request in terms of the request UUID, request source, ID, version, and other
 * metadata. The {@link LinkedHashMap} contains the lookups to be performed, keyed
 * by the lookup ID.
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefDataLookupRequest {
    private RefDataLookupAPIRequest dataLookupAPIRequest;
    private LinkedHashMap<String, RefDataLookup<?>> lookupsMap;
}
