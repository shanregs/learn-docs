package com.shan.spboot.ms.refdatalookup.refdata.api.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Represents the result of a individual reference data lookup.
 *
 * @param <T> the type of the values returned by the lookup
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefDataLookupResult <T> {
    private String lookupId;
    private String operation;
    private String status;
    private String errorMessage;
    private List<String> dependsOnLookupIds;
    private T values;
}
