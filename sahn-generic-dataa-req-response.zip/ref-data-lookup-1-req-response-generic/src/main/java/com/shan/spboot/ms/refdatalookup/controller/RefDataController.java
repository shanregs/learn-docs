package com.shan.spboot.ms.refdatalookup.controller;
import com.shan.spboot.ms.refdatalookup.refdata.api.RefDataLookupRequestBuilder;
import com.shan.spboot.ms.refdatalookup.refdata.api.consts.RefDataLookupIdEnum;
import com.shan.spboot.ms.refdatalookup.refdata.api.request.RefDataLookupAPIRequest;
import com.shan.spboot.ms.refdatalookup.refdata.api.request.RefDataLookupRequest;
import com.shan.spboot.ms.refdatalookup.trade.data.Trade;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/refdata")
public class RefDataController {

    @GetMapping("/hello")
    public RefDataLookupAPIRequest hello() {
        Trade trade = new Trade(56045454599L,1,"code", "CALYPS",
                "1234232323", "MSSLegalName");
        RefDataLookupRequest req = RefDataLookupRequestBuilder.buildLookupRequest(trade, RefDataLookupIdEnum.PARTY_LOOKUP_ID,
                RefDataLookupIdEnum.FXSPOT_LETTER_LOOKUP_ID);
        return req.getDataLookupAPIRequest();
    }
}
