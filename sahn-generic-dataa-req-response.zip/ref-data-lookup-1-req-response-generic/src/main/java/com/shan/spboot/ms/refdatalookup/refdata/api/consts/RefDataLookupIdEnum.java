package com.shan.spboot.ms.refdatalookup.refdata.api.consts;

public enum RefDataLookupIdEnum {

    PARTY_LOOKUP_ID("party_1"),
    UPI_1_LOOKUP_ID("upi_1"),
    UPI_2_LOOKUP_ID("upi_2"),
    FXSPOT_LETTER_LOOKUP_ID("fxSpotLetter_1");

    private final String lookupId;


    RefDataLookupIdEnum(String lookupId) {
        this.lookupId = lookupId;

    }

    public String getLookupId() {
        return lookupId;
    }


    public static RefDataLookupIdEnum fromLookupIdString(String lookupId) {
        for (RefDataLookupIdEnum b : RefDataLookupIdEnum.values()) {
            if (b.lookupId.equalsIgnoreCase(lookupId)) {
                return b;
            }
        }
        throw new IllegalArgumentException("No enum constant for " + lookupId);
    }

}
