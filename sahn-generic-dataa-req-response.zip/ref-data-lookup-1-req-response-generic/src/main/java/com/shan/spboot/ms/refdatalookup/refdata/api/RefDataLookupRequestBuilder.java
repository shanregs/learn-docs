package com.shan.spboot.ms.refdatalookup.refdata.api;

import com.shan.spboot.ms.refdatalookup.refdata.api.consts.RefDataLookupConstants;
import com.shan.spboot.ms.refdatalookup.refdata.api.consts.RefDataLookupIdEnum;
import com.shan.spboot.ms.refdatalookup.refdata.api.request.RefDataLookup;
import com.shan.spboot.ms.refdatalookup.refdata.api.request.RefDataLookupAPIRequest;
import com.shan.spboot.ms.refdatalookup.refdata.api.request.RefDataLookupRequest;
import com.shan.spboot.ms.refdatalookup.refdata.model.FxSpotLetter;
import com.shan.spboot.ms.refdatalookup.refdata.model.Party;
import com.shan.spboot.ms.refdatalookup.trade.data.Trade;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;

/**
 * Utility class that provides a builder method for RefDataLookupRequest objects.
 *
 * <p>This class offers a builder method that creates a RefDataLookupRequest object
 * using a trade object and an optional list of lookup types. It constructs a
 * RefDataLookupRequest by utilizing the trade object and an optional list of
 * lookup types.
 */

public class RefDataLookupRequestBuilder {

    public static RefDataLookupRequest buildLookupRequest(Trade tradeObj, RefDataLookupIdEnum... lookupTypes) {
        RefDataLookupRequest refDataLookupRequest = null;
        LinkedHashMap<String, RefDataLookup<?>> lookupsMap = new LinkedHashMap<>();
        ArrayList<RefDataLookup<?>> lookupList = new ArrayList<>();
        String requestUUID = UUID.randomUUID().toString();
        String requestSource = RefDataLookupConstants.APP_UI;
        Long id = Long.valueOf(tradeObj.getId());
        int version = tradeObj.getVersion();

        for (RefDataLookupIdEnum lookupType : lookupTypes) {
            createAndStoreLookup(lookupType, tradeObj, lookupList, lookupsMap);
        }
        RefDataLookupAPIRequest apiRequest = new RefDataLookupAPIRequest(
                requestUUID, requestSource, id, version  ,lookupList );

        refDataLookupRequest = new RefDataLookupRequest(apiRequest, lookupsMap);
        return refDataLookupRequest;
    }

    private static void createAndStoreLookup(RefDataLookupIdEnum lookupType, Trade tradeObj,
                                             ArrayList<RefDataLookup<?>> lookupList,
                                             LinkedHashMap<String, RefDataLookup<?>> lookupsMap) {
        switch (lookupType) {
            case PARTY_LOOKUP_ID:
                RefDataLookup<Party> partyLookup = createPartyLookup(tradeObj);
                lookupList.add(partyLookup);
                lookupsMap.put(RefDataLookupIdEnum.PARTY_LOOKUP_ID.getLookupId(),  partyLookup);
                break;

            case FXSPOT_LETTER_LOOKUP_ID:
                RefDataLookup<FxSpotLetter> fxSpotLetterLookup = createFxSpotLetterLookup(tradeObj);
                lookupList.add(fxSpotLetterLookup);
                lookupsMap.put(RefDataLookupIdEnum.FXSPOT_LETTER_LOOKUP_ID.getLookupId(),
                        fxSpotLetterLookup);
                break;

            default:
                System.out.println("Unsupported Lookup Type: " + lookupType);
        }
    }

    private static RefDataLookup<Party> createPartyLookup(Trade tradeObj) {
        return new RefDataLookup<>(
                RefDataLookupIdEnum.PARTY_LOOKUP_ID.getLookupId(),
                RefDataLookupConstants.PARTY_LOOKUP_OPERATION,
                new Party(tradeObj.getCode(), tradeObj.getSourceSystem())
        );
    }

    private static RefDataLookup<FxSpotLetter> createFxSpotLetterLookup(Trade tradeObj) {
        String fxSpotLetterLookupId =  RefDataLookupIdEnum.FXSPOT_LETTER_LOOKUP_ID.getLookupId();
        return new RefDataLookup<>(fxSpotLetterLookupId,
                RefDataLookupConstants.FXSPOT_LETTER_LOOKUP_OPERATION,
                new FxSpotLetter(tradeObj.getAccount(), tradeObj.getSourceSystem(),
                        "{{party_1.legalName}}"),
                List.of(fxSpotLetterLookupId)
        );
    }
    private static String getLookupId(RefDataLookupIdEnum lookupType) {
        return switch (lookupType) {
            case PARTY_LOOKUP_ID -> RefDataLookupIdEnum.PARTY_LOOKUP_ID.getLookupId();
            case FXSPOT_LETTER_LOOKUP_ID -> RefDataLookupIdEnum.FXSPOT_LETTER_LOOKUP_ID.getLookupId();
            default -> "";
        };
    }
}
