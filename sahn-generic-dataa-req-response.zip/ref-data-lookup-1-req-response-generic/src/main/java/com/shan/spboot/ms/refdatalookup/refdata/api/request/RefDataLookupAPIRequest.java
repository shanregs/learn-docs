package com.shan.spboot.ms.refdatalookup.refdata.api.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

/**
 * API request for ref data lookups.
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefDataLookupAPIRequest {
    private String requestUUID;
    private String requestSource;
    private Long id;
    private int version;
    private ArrayList<RefDataLookup<?>> lookups;
}
