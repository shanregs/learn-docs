package com.shan.spboot.ms.refdatalookup.refdata.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Party {
    private String code;
    private String sourceSystem;
}
