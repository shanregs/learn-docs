package com.shan.spboot.ms.refdatalookup.refdata.api.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Represents an individual reference data lookup request.
 *
 * The lookups will be processed in the order they appear in the list.
 * Each lookup will be processed as follows:
 *
 * if the lookup's dependsOnLookupIds is empty, the lookup will be processed immediately
 * if the lookup's dependsOnLookupIds is not empty, the lookup will only be processed after all the lookups
 * in the dependsOnLookupIds list have been processed
 *
 * @param <T> the type of the parameter
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefDataLookup<T> {
    private String lookupId;
    private String operation;
    private T params;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<String> dependsOnLookupIds;

    public RefDataLookup(String lookupId, String operation, T params) {
        this.lookupId = lookupId;
        this.operation = operation;
        this.params = params;
    }
}

